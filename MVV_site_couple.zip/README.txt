MVV — site de couple
1. Ouvre index.html dans un navigateur.
2. Modifie les textes/photos quand tu veux.
3. Le code secret de démonstration est 070625.
Le site est entièrement statique : aucune donnée n'est envoyée en ligne.
