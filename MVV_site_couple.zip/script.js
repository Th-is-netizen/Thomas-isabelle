const heart=document.getElementById('heart'), heartText=document.getElementById('heartText');
heart.onclick=()=>{heartText.textContent="« Jusqu'au bout, peu importe les difficultés. » ❤️"; for(let i=0;i<12;i++){const s=document.createElement('span');s.textContent='♥';s.style.cssText=`position:fixed;left:${45+Math.random()*10}%;top:60%;color:#b72b3b;font-size:${12+Math.random()*20}px;z-index:30;pointer-events:none;animation:float 1.5s ease-out forwards`;document.body.appendChild(s);setTimeout(()=>s.remove(),1500)}};
const style=document.createElement('style');style.textContent='@keyframes float{to{transform:translateY(-180px) translateX('+(-80+Math.random()*160)+'px);opacity:0}}';document.head.appendChild(style);

document.querySelectorAll('[data-msg]').forEach(b=>b.onclick=()=>{document.getElementById('modalText').textContent=b.dataset.msg;document.getElementById('modal').classList.add('show')});
document.getElementById('close').onclick=()=>document.getElementById('modal').classList.remove('show');
document.getElementById('modal').onclick=e=>{if(e.target.id==='modal')e.currentTarget.classList.remove('show')};

document.getElementById('unlock').onclick=()=>{
  const code=document.getElementById('code').value.trim();
  const out=document.getElementById('secretText');
  if(code==='070625') out.textContent="🔓 Bienvenue dans votre espace secret. La vraie surprise pourra être ajoutée ici plus tard…";
  else out.textContent="🔒 Pas encore… ce coffre attend le bon code.";
};
